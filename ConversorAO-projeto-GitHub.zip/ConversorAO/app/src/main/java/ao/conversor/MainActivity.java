package ao.conversor;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import org.json.JSONObject;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(15,18,26), panel = Color.rgb(29,34,46), gold = Color.rgb(255,202,0), white = Color.WHITE;
    private EditText amount;
    private Spinner from, to;
    private TextView result, status, rateInfo, history;
    private double usdAoa = 0, brlAoa = 0;
    private String rateDate = "—";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final String[] codes = {"AOA", "USD", "BRL"};
    private final String[] labels = {"Kwanza (AOA)", "Dólar (USD)", "Real (BRL)"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        buildUi();
        loadRates();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(22, 28, 22, 24); page.setBackgroundColor(bg); scroll.addView(page);
        TextView title = text("ConversorAO", 30, gold, true); page.addView(title);
        page.addView(text("Converta • Compare • Poupe", 14, 0xFFB8BFCC, false));
        page.addView(space(22));
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18,18,18,18); card.setBackgroundColor(panel); page.addView(card);
        card.addView(text("Valor a converter", 15, 0xFFB8BFCC, false));
        amount = new EditText(this); amount.setSingleLine(true); amount.setText("100");
        amount.setTextSize(25); amount.setTextColor(white); amount.setHintTextColor(0xFF87909E);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        amount.setHint("Introduza o valor"); card.addView(amount);
        card.addView(space(10));
        card.addView(text("De:", 14, white, true));
        from = new Spinner(this); to = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels);
        from.setAdapter(adapter); to.setAdapter(adapter); from.setSelection(0); to.setSelection(1);
        card.addView(from); card.addView(space(8));
        card.addView(text("Para:", 14, white, true)); card.addView(to);
        Button swap = new Button(this); swap.setText("⇄  Inverter moedas"); card.addView(swap);
        Button convert = new Button(this); convert.setText("CONVERTER"); convert.setTextColor(Color.BLACK);
        convert.setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold)); card.addView(convert);
        result = text("—", 28, white, true); result.setGravity(Gravity.CENTER);
        LinearLayout output = new LinearLayout(this); output.setOrientation(LinearLayout.VERTICAL);
        output.setPadding(16,20,16,20); output.setGravity(Gravity.CENTER); output.setBackgroundColor(0xFF202838);
        output.addView(text("Resultado", 14, 0xFFB8BFCC, false)); output.addView(result); card.addView(space(12)); card.addView(output);
        rateInfo = text("Fonte: Banco Nacional de Angola (BNA)", 12, 0xFFB8BFCC, false);
        rateInfo.setPadding(0,14,0,0); card.addView(rateInfo);
        status = text("A obter taxas de câmbio…", 12, 0xFF30D17B, false); card.addView(status);
        convert.setOnClickListener(v -> calculate());
        swap.setOnClickListener(v -> { int a=from.getSelectedItemPosition(); from.setSelection(to.getSelectedItemPosition()); to.setSelection(a); calculate(); });
        page.addView(space(24));
        TextView about = text("SOBRE", 18, gold, true); page.addView(about);
        page.addView(text("ConversorAO — aplicação de conversão de moedas para utilização em Angola.\n\nCriador: Dionísio Cláudio\nEmail: dionisio.claudio@outlook.pt\nTelefone: +244 941 414 187\nInstagram: @dc.way", 14, white, false));
        page.addView(space(12));
        page.addView(text("As taxas são referências oficiais publicadas pelo BNA. Não representam necessariamente a taxa praticada por bancos, casas de câmbio ou mercado informal.", 12, 0xFF9DA6B5, false));
        setContentView(scroll);
    }
    private View space(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,h)); return v; }

    private void loadCachedRates() {
        android.content.SharedPreferences prefs = getSharedPreferences("rates", MODE_PRIVATE);
        usdAoa = Double.longBitsToDouble(prefs.getLong("usd", 0));
        brlAoa = Double.longBitsToDouble(prefs.getLong("brl", 0));
        rateDate = prefs.getString("date", "—");
        String savedHistory = prefs.getString("history", "Ainda não há conversões.");
        history.setText(savedHistory);
        if (usdAoa > 0 && brlAoa > 0) {
            status.setText("A usar última cotação guardada • " + rateDate);
            rateInfo.setText("Última referência BNA guardada • 1 USD = " + fmt(usdAoa) + " Kz • 1 BRL = " + fmt(brlAoa) + " Kz");
            calculate();
        }
    }
    private void loadRates() {
        executor.execute(() -> {
            try {
                JSONObject usd = getJson("https://allratestoday.com/api/open/central-bank/bna?source=USD&target=AOA");
                JSONObject brl = getJson("https://allratestoday.com/api/open/central-bank/bna?source=BRL&target=AOA");
                double u = usd.getDouble("rate"), b = brl.getDouble("rate");
                String d = usd.optString("rate_date", "data não indicada");
                runOnUiThread(() -> {
                    usdAoa=u; brlAoa=b; rateDate=d;
                    status.setText("✓ Taxas atualizadas • " + d);
                    rateInfo.setText("Fonte: BNA / AllRatesToday • 1 USD = " + fmt(u) + " Kz • 1 BRL = " + fmt(b) + " Kz");
                    calculate();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("Sem ligação ou fonte indisponível. Tente novamente.");
                    rateInfo.setText("Não foi possível confirmar taxas atuais. A conversão fica indisponível até atualizar.");
                });
            }
        });
    }
    private JSONObject getJson(String address) throws Exception {
        HttpsURLConnection c = (HttpsURLConnection) new URL(address).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(12000); c.setRequestMethod("GET");
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder s = new StringBuilder(); String line;
        while ((line=r.readLine())!=null) s.append(line);
        r.close(); c.disconnect(); return new JSONObject(s.toString());
    }
    private double toAoa(String code) { if (code.equals("AOA")) return 1; if (code.equals("USD")) return usdAoa; return brlAoa; }
    private void calculate() {
        if (usdAoa<=0 || brlAoa<=0) return;
        try {
            double value=Double.parseDouble(amount.getText().toString().replace(",", "."));
            int f=from.getSelectedItemPosition(), t=to.getSelectedItemPosition();
            double converted=value*toAoa(codes[f])/toAoa(codes[t]);
            String output = fmt(converted)+" "+codes[t];
            result.setText(output);
            String entry = fmt(value)+" "+codes[f]+" → "+output;
            String old = getSharedPreferences("rates", MODE_PRIVATE).getString("history", "");
            String updated = entry + (old.isEmpty() || old.equals("Ainda não há conversões.") ? "" : "\\n"+old);
            String[] lines = updated.split("\\n");
            StringBuilder shortHistory = new StringBuilder();
            for (int i=0; i<Math.min(5, lines.length); i++) { if(i>0) shortHistory.append("\\n"); shortHistory.append(lines[i]); }
            history.setText(shortHistory.toString());
            getSharedPreferences("rates", MODE_PRIVATE).edit().putString("history", shortHistory.toString()).apply();
        } catch(Exception e) { result.setText("Introduza um valor válido"); }
    }
    private String fmt(double v) { return String.format(Locale.getDefault(), "%,.2f", v); }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdown(); }
}
