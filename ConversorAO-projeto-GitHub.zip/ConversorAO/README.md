# ConversorAO

Aplicativo Android simples para conversão entre Kwanza (AOA), Dólar (USD) e Real (BRL).

## Taxas de câmbio
O app consulta as taxas de referência publicadas pelo Banco Nacional de Angola (BNA), através do endpoint aberto AllRatesToday:
- USD/AOA: https://allratestoday.com/api/open/central-bank/bna?source=USD&target=AOA
- BRL/AOA: https://allratestoday.com/api/open/central-bank/bna?source=BRL&target=AOA

A data de publicação é apresentada no aplicativo. As taxas são oficiais de referência, não cotações de compra/venda de cada banco ou do mercado informal. A ligação à internet é necessária para atualizar as taxas. Se a fonte não responder, o app pode usar a última cotação guardada, identificando-a como guardada e mantendo a respetiva data. O histórico local mostra até cinco conversões recentes.

## Criar o APK pelo telemóvel
1. Descompacte este ZIP no telemóvel.
2. Abra https://github.com e entre na sua conta.
3. Toque em **+** > **New repository**.
4. Nome: `ConversorAO`; escolha **Public** ou **Private** e crie o repositório.
5. Dentro do repositório, use **Add file** > **Upload files**.
6. Envie todos os ficheiros e pastas que estão dentro da pasta `ConversorAO` (incluindo `.github`). Confirme em **Commit changes**.
7. Abra o separador **Actions**. Aguarde o workflow **Construir APK ConversorAO** terminar com marca verde.
8. Abra a execução concluída, desça até **Artifacts** e toque em **ConversorAO-APK** para descarregar o APK.
9. Extraia o ZIP descarregado e instale `app-debug.apk`. O Android poderá pedir autorização para instalar aplicações desta origem.

## Notas
- O APK é gerado automaticamente pelo GitHub Actions; este pacote contém o código-fonte e a configuração de compilação, não um APK já compilado.
- O ícone ConversorAO está incluído em `app/src/main/res/drawable/ic_conversorao.xml`.
- Contactos na página Sobre: Dionísio Cláudio · dionisio.claudio@outlook.pt · +244 941 414 187 · @dc.way.
